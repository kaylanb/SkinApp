pandas.DatetimeIndex.mean
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.mean