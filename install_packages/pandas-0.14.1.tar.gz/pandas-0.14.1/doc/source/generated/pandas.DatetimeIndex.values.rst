pandas.DatetimeIndex.values
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.values