pandas.Panel4D.xs
=================

.. currentmodule:: pandas

.. automethod:: Panel4D.xs