pandas.Index.set_value
======================

.. currentmodule:: pandas

.. automethod:: Index.set_value