pandas.Index.data
=================

.. currentmodule:: pandas

.. autoattribute:: Index.data