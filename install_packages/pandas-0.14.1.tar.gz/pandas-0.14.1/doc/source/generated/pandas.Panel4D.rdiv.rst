pandas.Panel4D.rdiv
===================

.. currentmodule:: pandas

.. automethod:: Panel4D.rdiv