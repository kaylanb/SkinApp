pandas.Index.is_floating
========================

.. currentmodule:: pandas

.. automethod:: Index.is_floating