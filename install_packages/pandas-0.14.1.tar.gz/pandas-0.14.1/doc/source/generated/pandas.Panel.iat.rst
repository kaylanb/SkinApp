pandas.Panel.iat
================

.. currentmodule:: pandas

.. autoattribute:: Panel.iat