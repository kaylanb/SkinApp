pandas.DatetimeIndex.get_duplicates
===================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.get_duplicates