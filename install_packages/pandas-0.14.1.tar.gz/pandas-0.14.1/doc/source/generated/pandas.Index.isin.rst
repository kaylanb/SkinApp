pandas.Index.isin
=================

.. currentmodule:: pandas

.. automethod:: Index.isin