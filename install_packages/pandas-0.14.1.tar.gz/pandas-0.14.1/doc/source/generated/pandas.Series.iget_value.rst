pandas.Series.iget_value
========================

.. currentmodule:: pandas

.. automethod:: Series.iget_value