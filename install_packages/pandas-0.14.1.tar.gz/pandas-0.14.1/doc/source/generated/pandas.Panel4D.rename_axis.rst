pandas.Panel4D.rename_axis
==========================

.. currentmodule:: pandas

.. automethod:: Panel4D.rename_axis