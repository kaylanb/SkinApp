pandas.Panel.loc
================

.. currentmodule:: pandas

.. autoattribute:: Panel.loc