pandas.DataFrame.to_gbq
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_gbq