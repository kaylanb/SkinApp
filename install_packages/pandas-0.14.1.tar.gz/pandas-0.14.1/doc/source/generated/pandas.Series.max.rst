pandas.Series.max
=================

.. currentmodule:: pandas

.. automethod:: Series.max