pandas.DatetimeIndex.copy
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.copy