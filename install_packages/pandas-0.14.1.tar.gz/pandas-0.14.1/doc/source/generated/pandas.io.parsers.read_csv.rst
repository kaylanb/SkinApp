pandas.io.parsers.read_csv
==========================

.. currentmodule:: pandas.io.parsers

.. autofunction:: read_csv