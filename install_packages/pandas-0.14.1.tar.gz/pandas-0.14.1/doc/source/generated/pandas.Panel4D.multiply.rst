pandas.Panel4D.multiply
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.multiply