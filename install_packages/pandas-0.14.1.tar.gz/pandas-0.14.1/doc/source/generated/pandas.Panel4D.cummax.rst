pandas.Panel4D.cummax
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.cummax