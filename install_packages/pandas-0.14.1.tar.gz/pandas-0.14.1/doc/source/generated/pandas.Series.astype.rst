pandas.Series.astype
====================

.. currentmodule:: pandas

.. automethod:: Series.astype