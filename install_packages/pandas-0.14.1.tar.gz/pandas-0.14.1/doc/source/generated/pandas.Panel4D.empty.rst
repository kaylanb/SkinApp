pandas.Panel4D.empty
====================

.. currentmodule:: pandas

.. autoattribute:: Panel4D.empty