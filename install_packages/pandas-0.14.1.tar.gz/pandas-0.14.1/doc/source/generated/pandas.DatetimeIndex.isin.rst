pandas.DatetimeIndex.isin
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.isin