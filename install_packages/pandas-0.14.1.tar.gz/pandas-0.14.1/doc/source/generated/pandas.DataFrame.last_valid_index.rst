pandas.DataFrame.last_valid_index
=================================

.. currentmodule:: pandas

.. automethod:: DataFrame.last_valid_index