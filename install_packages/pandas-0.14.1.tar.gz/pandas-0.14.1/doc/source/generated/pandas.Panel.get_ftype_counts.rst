pandas.Panel.get_ftype_counts
=============================

.. currentmodule:: pandas

.. automethod:: Panel.get_ftype_counts