pandas.Panel4D.to_frame
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.to_frame