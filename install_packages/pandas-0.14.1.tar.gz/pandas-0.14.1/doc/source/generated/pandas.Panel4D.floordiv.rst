pandas.Panel4D.floordiv
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.floordiv