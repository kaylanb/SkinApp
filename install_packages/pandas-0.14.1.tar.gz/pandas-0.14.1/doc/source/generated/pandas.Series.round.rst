pandas.Series.round
===================

.. currentmodule:: pandas

.. automethod:: Series.round