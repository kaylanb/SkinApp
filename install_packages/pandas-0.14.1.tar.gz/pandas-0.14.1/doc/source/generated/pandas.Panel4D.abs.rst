pandas.Panel4D.abs
==================

.. currentmodule:: pandas

.. automethod:: Panel4D.abs