pandas.Panel.last
=================

.. currentmodule:: pandas

.. automethod:: Panel.last