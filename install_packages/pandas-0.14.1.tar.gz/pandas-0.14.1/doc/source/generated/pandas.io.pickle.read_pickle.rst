pandas.io.pickle.read_pickle
============================

.. currentmodule:: pandas.io.pickle

.. autofunction:: read_pickle