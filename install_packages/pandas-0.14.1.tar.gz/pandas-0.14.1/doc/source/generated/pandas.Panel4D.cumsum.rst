pandas.Panel4D.cumsum
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.cumsum