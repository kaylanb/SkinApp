pandas.DatetimeIndex.byteswap
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.byteswap