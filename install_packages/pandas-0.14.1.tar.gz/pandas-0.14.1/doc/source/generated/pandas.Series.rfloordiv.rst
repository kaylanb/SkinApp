pandas.Series.rfloordiv
=======================

.. currentmodule:: pandas

.. automethod:: Series.rfloordiv