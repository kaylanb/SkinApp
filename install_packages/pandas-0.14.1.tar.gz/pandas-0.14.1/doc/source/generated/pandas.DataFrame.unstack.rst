pandas.DataFrame.unstack
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.unstack