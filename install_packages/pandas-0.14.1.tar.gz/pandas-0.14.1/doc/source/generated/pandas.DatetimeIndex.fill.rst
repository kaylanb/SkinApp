pandas.DatetimeIndex.fill
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.fill