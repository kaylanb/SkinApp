pandas.Series.shape
===================

.. currentmodule:: pandas

.. autoattribute:: Series.shape