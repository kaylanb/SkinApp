pandas.core.strings.StringMethods.len
=====================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.len