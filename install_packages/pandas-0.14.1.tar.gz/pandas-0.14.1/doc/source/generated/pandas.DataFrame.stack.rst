pandas.DataFrame.stack
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.stack