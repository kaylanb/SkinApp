pandas.Index.nlevels
====================

.. currentmodule:: pandas

.. autoattribute:: Index.nlevels