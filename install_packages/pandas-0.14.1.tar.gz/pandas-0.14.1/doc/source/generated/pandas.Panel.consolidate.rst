pandas.Panel.consolidate
========================

.. currentmodule:: pandas

.. automethod:: Panel.consolidate