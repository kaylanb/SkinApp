pandas.Index.imag
=================

.. currentmodule:: pandas

.. autoattribute:: Index.imag