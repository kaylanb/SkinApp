pandas.core.strings.StringMethods.decode
========================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.decode