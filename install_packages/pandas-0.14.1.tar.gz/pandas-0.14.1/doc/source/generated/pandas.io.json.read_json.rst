pandas.io.json.read_json
========================

.. currentmodule:: pandas.io.json

.. autofunction:: read_json