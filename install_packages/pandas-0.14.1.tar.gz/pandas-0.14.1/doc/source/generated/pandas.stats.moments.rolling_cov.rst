pandas.stats.moments.rolling_cov
================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: rolling_cov