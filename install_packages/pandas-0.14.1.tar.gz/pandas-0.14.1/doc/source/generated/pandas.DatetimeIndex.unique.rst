pandas.DatetimeIndex.unique
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.unique