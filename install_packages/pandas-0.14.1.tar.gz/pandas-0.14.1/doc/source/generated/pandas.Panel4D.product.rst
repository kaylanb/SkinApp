pandas.Panel4D.product
======================

.. currentmodule:: pandas

.. automethod:: Panel4D.product