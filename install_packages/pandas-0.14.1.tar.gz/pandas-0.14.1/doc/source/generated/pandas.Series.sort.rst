pandas.Series.sort
==================

.. currentmodule:: pandas

.. automethod:: Series.sort