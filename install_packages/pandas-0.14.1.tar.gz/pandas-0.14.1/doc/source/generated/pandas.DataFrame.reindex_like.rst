pandas.DataFrame.reindex_like
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.reindex_like