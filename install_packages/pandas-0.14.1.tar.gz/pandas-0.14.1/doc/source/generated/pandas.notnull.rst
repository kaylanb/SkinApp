pandas.notnull
==============

.. currentmodule:: pandas

.. autofunction:: notnull