pandas.Panel4D.sub
==================

.. currentmodule:: pandas

.. automethod:: Panel4D.sub