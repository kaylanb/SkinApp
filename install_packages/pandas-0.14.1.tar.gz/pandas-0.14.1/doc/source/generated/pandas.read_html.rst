pandas.read_html
================

.. currentmodule:: pandas

.. autofunction:: read_html