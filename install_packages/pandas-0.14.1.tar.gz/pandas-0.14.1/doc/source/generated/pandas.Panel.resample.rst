pandas.Panel.resample
=====================

.. currentmodule:: pandas

.. automethod:: Panel.resample