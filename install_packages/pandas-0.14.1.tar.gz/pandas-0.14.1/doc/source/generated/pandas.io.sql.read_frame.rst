pandas.io.sql.read_frame
========================

.. currentmodule:: pandas.io.sql

.. autofunction:: read_frame