pandas.DataFrame.rename
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.rename