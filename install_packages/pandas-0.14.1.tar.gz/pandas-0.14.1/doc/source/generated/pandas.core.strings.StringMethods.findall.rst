pandas.core.strings.StringMethods.findall
=========================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.findall