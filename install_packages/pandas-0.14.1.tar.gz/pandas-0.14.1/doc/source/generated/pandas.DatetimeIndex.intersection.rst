pandas.DatetimeIndex.intersection
=================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.intersection