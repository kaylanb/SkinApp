pandas.Series.between_time
==========================

.. currentmodule:: pandas

.. automethod:: Series.between_time