pandas.DatetimeIndex.compress
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.compress