pandas.Panel.values
===================

.. currentmodule:: pandas

.. autoattribute:: Panel.values