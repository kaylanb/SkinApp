pandas.Panel4D.clip_upper
=========================

.. currentmodule:: pandas

.. automethod:: Panel4D.clip_upper