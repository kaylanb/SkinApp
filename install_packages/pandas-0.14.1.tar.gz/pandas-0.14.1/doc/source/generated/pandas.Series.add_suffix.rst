pandas.Series.add_suffix
========================

.. currentmodule:: pandas

.. automethod:: Series.add_suffix