pandas.Series.rsub
==================

.. currentmodule:: pandas

.. automethod:: Series.rsub