pandas.Index.compress
=====================

.. currentmodule:: pandas

.. automethod:: Index.compress