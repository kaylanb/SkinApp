pandas.io.stata.StataReader.value_labels
========================================

.. currentmodule:: pandas.io.stata

.. automethod:: StataReader.value_labels