pandas.Index.T
==============

.. currentmodule:: pandas

.. autoattribute:: Index.T