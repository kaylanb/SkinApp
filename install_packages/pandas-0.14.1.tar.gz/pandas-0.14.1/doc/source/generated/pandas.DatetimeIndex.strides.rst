pandas.DatetimeIndex.strides
============================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.strides