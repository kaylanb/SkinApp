pandas.Panel.to_frame
=====================

.. currentmodule:: pandas

.. automethod:: Panel.to_frame