pandas.DatetimeIndex.day
========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.day