pandas.core.strings.StringMethods.lower
=======================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.lower