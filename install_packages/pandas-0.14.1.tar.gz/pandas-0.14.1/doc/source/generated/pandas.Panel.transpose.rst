pandas.Panel.transpose
======================

.. currentmodule:: pandas

.. automethod:: Panel.transpose