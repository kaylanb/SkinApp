pandas.DatetimeIndex.T
======================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.T