pandas.core.strings.StringMethods.slice
=======================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.slice