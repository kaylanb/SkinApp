pandas.Series.last_valid_index
==============================

.. currentmodule:: pandas

.. automethod:: Series.last_valid_index