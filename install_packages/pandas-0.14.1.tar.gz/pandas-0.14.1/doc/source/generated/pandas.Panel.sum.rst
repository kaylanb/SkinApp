pandas.Panel.sum
================

.. currentmodule:: pandas

.. automethod:: Panel.sum