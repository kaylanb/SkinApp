pandas.DataFrame.truncate
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.truncate