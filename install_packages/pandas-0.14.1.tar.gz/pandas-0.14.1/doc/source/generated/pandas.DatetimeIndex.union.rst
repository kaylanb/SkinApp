pandas.DatetimeIndex.union
==========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.union