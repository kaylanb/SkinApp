pandas.DatetimeIndex.dump
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.dump