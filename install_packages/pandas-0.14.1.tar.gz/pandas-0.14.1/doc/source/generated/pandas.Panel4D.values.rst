pandas.Panel4D.values
=====================

.. currentmodule:: pandas

.. autoattribute:: Panel4D.values