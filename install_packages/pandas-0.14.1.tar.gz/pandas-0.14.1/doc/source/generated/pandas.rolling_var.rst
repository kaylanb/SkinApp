pandas.rolling_var
==================

.. currentmodule:: pandas

.. autofunction:: rolling_var