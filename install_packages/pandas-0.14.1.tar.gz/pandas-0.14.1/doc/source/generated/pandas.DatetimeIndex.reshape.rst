pandas.DatetimeIndex.reshape
============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.reshape