pandas.Index.unique
===================

.. currentmodule:: pandas

.. automethod:: Index.unique