pandas.rolling_apply
====================

.. currentmodule:: pandas

.. autofunction:: rolling_apply