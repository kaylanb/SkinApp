pandas.DatetimeIndex.get_indexer
================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.get_indexer