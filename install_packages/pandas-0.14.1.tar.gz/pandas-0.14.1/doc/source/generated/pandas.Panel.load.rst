pandas.Panel.load
=================

.. currentmodule:: pandas

.. automethod:: Panel.load