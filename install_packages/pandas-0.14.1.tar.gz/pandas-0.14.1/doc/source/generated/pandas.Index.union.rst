pandas.Index.union
==================

.. currentmodule:: pandas

.. automethod:: Index.union