pandas.Index.get_level_values
=============================

.. currentmodule:: pandas

.. automethod:: Index.get_level_values