pandas.Index.get_duplicates
===========================

.. currentmodule:: pandas

.. automethod:: Index.get_duplicates