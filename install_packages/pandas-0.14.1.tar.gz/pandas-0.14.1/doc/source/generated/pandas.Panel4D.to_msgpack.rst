pandas.Panel4D.to_msgpack
=========================

.. currentmodule:: pandas

.. automethod:: Panel4D.to_msgpack