pandas.Series.le
================

.. currentmodule:: pandas

.. automethod:: Series.le