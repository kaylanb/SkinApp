pandas.melt
===========

.. currentmodule:: pandas

.. autofunction:: melt