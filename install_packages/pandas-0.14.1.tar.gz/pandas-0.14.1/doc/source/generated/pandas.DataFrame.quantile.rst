pandas.DataFrame.quantile
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.quantile