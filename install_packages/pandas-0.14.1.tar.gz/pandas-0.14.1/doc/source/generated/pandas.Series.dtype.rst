pandas.Series.dtype
===================

.. currentmodule:: pandas

.. autoattribute:: Series.dtype