pandas.Index.asof
=================

.. currentmodule:: pandas

.. automethod:: Index.asof