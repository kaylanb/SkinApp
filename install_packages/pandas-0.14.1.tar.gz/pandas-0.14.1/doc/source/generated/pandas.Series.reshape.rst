pandas.Series.reshape
=====================

.. currentmodule:: pandas

.. automethod:: Series.reshape