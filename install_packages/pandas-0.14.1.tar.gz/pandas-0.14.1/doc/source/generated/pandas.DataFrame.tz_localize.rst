pandas.DataFrame.tz_localize
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.tz_localize