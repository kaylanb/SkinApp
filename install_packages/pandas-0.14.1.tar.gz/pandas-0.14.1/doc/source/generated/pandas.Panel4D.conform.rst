pandas.Panel4D.conform
======================

.. currentmodule:: pandas

.. automethod:: Panel4D.conform