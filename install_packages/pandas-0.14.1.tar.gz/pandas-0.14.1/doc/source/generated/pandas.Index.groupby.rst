pandas.Index.groupby
====================

.. currentmodule:: pandas

.. automethod:: Index.groupby