pandas.Panel4D.convert_objects
==============================

.. currentmodule:: pandas

.. automethod:: Panel4D.convert_objects