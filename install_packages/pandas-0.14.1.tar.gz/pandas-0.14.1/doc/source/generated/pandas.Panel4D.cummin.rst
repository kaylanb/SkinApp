pandas.Panel4D.cummin
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.cummin