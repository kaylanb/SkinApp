pandas.DataFrame.from_csv
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_csv