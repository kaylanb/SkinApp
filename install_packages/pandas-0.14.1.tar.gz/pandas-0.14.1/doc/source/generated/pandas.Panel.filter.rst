pandas.Panel.filter
===================

.. currentmodule:: pandas

.. automethod:: Panel.filter