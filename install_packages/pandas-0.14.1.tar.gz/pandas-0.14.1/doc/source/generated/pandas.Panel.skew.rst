pandas.Panel.skew
=================

.. currentmodule:: pandas

.. automethod:: Panel.skew