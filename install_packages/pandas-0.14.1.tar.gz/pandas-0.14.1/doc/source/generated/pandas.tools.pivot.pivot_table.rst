pandas.tools.pivot.pivot_table
==============================

.. currentmodule:: pandas.tools.pivot

.. autofunction:: pivot_table