pandas.Panel4D.consolidate
==========================

.. currentmodule:: pandas

.. automethod:: Panel4D.consolidate