pandas.Panel4D.var
==================

.. currentmodule:: pandas

.. automethod:: Panel4D.var