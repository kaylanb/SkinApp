pandas.Panel.median
===================

.. currentmodule:: pandas

.. automethod:: Panel.median