pandas.isnull
=============

.. currentmodule:: pandas

.. autofunction:: isnull