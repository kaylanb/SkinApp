pandas.Index.equals
===================

.. currentmodule:: pandas

.. automethod:: Index.equals