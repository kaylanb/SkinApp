pandas.Panel.clip_upper
=======================

.. currentmodule:: pandas

.. automethod:: Panel.clip_upper