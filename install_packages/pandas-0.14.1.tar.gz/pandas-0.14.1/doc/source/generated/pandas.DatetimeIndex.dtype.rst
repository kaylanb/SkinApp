pandas.DatetimeIndex.dtype
==========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.dtype