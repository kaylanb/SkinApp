pandas.HDFStore.select
======================

.. currentmodule:: pandas

.. automethod:: HDFStore.select