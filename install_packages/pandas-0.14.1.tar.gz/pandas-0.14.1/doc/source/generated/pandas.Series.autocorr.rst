pandas.Series.autocorr
======================

.. currentmodule:: pandas

.. automethod:: Series.autocorr