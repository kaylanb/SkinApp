pandas.core.reshape.get_dummies
===============================

.. currentmodule:: pandas.core.reshape

.. autofunction:: get_dummies