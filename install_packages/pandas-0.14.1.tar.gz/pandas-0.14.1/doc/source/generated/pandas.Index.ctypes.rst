pandas.Index.ctypes
===================

.. currentmodule:: pandas

.. autoattribute:: Index.ctypes