pandas.rolling_skew
===================

.. currentmodule:: pandas

.. autofunction:: rolling_skew