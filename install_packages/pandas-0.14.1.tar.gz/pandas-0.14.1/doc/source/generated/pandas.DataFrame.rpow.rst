pandas.DataFrame.rpow
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.rpow