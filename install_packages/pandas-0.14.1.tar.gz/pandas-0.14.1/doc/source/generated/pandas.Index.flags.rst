pandas.Index.flags
==================

.. currentmodule:: pandas

.. autoattribute:: Index.flags