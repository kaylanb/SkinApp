pandas.DatetimeIndex.shape
==========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.shape