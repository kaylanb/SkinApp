pandas.merge
============

.. currentmodule:: pandas

.. autofunction:: merge