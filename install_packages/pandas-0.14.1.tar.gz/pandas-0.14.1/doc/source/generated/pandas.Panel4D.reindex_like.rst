pandas.Panel4D.reindex_like
===========================

.. currentmodule:: pandas

.. automethod:: Panel4D.reindex_like