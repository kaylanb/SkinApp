pandas.Series.pct_change
========================

.. currentmodule:: pandas

.. automethod:: Series.pct_change