pandas.Panel.truediv
====================

.. currentmodule:: pandas

.. automethod:: Panel.truediv