pandas.expanding_cov
====================

.. currentmodule:: pandas

.. autofunction:: expanding_cov