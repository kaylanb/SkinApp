pandas.Panel.count
==================

.. currentmodule:: pandas

.. automethod:: Panel.count