pandas.expanding_std
====================

.. currentmodule:: pandas

.. autofunction:: expanding_std