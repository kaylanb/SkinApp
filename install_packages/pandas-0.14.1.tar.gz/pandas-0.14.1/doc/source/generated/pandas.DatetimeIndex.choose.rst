pandas.DatetimeIndex.choose
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.choose