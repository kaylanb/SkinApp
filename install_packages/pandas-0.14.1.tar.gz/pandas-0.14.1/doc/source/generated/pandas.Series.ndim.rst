pandas.Series.ndim
==================

.. currentmodule:: pandas

.. autoattribute:: Series.ndim