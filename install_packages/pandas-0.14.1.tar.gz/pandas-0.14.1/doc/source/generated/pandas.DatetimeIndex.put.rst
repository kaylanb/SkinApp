pandas.DatetimeIndex.put
========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.put