pandas.DatetimeIndex.prod
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.prod