pandas.Series.cummax
====================

.. currentmodule:: pandas

.. automethod:: Series.cummax