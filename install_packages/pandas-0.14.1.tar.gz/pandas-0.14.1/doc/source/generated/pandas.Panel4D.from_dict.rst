pandas.Panel4D.from_dict
========================

.. currentmodule:: pandas

.. automethod:: Panel4D.from_dict