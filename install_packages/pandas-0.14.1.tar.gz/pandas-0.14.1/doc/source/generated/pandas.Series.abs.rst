pandas.Series.abs
=================

.. currentmodule:: pandas

.. automethod:: Series.abs