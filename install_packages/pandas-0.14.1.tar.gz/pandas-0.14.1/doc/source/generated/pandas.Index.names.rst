pandas.Index.names
==================

.. currentmodule:: pandas

.. autoattribute:: Index.names