pandas.Panel.multiply
=====================

.. currentmodule:: pandas

.. automethod:: Panel.multiply