pandas.io.pytables.HDFStore.get
===============================

.. currentmodule:: pandas.io.pytables

.. automethod:: HDFStore.get