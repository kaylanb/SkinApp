pandas.Index.swapaxes
=====================

.. currentmodule:: pandas

.. automethod:: Index.swapaxes