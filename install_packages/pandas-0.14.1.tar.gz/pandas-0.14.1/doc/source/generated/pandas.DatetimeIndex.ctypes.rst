pandas.DatetimeIndex.ctypes
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.ctypes