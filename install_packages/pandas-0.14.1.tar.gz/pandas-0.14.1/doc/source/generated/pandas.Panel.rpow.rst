pandas.Panel.rpow
=================

.. currentmodule:: pandas

.. automethod:: Panel.rpow