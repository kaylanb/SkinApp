pandas.Series.asfreq
====================

.. currentmodule:: pandas

.. automethod:: Series.asfreq