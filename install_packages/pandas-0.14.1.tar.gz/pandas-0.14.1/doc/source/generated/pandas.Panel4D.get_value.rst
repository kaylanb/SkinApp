pandas.Panel4D.get_value
========================

.. currentmodule:: pandas

.. automethod:: Panel4D.get_value