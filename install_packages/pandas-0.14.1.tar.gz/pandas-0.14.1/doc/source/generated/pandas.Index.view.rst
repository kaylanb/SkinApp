pandas.Index.view
=================

.. currentmodule:: pandas

.. automethod:: Index.view