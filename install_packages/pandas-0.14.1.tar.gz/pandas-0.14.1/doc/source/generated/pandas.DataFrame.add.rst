pandas.DataFrame.add
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.add