pandas.Panel.tz_convert
=======================

.. currentmodule:: pandas

.. automethod:: Panel.tz_convert