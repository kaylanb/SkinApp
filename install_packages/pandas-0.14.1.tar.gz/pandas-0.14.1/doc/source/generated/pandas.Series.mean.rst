pandas.Series.mean
==================

.. currentmodule:: pandas

.. automethod:: Series.mean