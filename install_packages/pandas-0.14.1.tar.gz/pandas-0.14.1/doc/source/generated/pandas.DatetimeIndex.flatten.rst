pandas.DatetimeIndex.flatten
============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.flatten