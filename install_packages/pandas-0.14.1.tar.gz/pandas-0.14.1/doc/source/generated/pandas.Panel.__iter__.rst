pandas.Panel.__iter__
=====================

.. currentmodule:: pandas

.. automethod:: Panel.__iter__