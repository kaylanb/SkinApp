pandas.DataFrame.load
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.load