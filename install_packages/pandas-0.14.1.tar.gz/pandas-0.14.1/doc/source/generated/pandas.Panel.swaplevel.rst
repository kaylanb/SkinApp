pandas.Panel.swaplevel
======================

.. currentmodule:: pandas

.. automethod:: Panel.swaplevel