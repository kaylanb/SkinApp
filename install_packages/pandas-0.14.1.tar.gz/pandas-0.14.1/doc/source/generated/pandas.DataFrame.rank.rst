pandas.DataFrame.rank
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.rank