pandas.Index.ndim
=================

.. currentmodule:: pandas

.. autoattribute:: Index.ndim