pandas.Index.argsort
====================

.. currentmodule:: pandas

.. automethod:: Index.argsort