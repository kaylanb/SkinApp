pandas.DatetimeIndex.slice_indexer
==================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.slice_indexer