pandas.Series.nanosecond
========================

.. currentmodule:: pandas

.. autoattribute:: Series.nanosecond