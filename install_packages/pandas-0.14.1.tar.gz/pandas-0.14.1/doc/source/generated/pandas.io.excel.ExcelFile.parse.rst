pandas.io.excel.ExcelFile.parse
===============================

.. currentmodule:: pandas.io.excel

.. automethod:: ExcelFile.parse