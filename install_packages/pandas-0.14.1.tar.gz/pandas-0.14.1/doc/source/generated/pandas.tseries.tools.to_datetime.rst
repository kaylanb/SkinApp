pandas.tseries.tools.to_datetime
================================

.. currentmodule:: pandas.tseries.tools

.. autofunction:: to_datetime