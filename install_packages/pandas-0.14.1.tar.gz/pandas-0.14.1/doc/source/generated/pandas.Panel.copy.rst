pandas.Panel.copy
=================

.. currentmodule:: pandas

.. automethod:: Panel.copy