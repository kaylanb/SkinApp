pandas.DataFrame.iloc
=====================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.iloc