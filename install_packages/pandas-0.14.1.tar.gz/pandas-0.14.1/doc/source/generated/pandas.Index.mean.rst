pandas.Index.mean
=================

.. currentmodule:: pandas

.. automethod:: Index.mean