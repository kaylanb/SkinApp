pandas.Panel.le
===============

.. currentmodule:: pandas

.. automethod:: Panel.le