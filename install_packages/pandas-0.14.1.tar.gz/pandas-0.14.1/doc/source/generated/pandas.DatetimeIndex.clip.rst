pandas.DatetimeIndex.clip
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.clip