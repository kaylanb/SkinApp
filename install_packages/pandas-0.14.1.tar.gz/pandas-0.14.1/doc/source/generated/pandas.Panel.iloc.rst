pandas.Panel.iloc
=================

.. currentmodule:: pandas

.. autoattribute:: Panel.iloc