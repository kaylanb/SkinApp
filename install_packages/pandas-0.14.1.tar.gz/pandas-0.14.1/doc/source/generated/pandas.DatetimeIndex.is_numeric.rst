pandas.DatetimeIndex.is_numeric
===============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.is_numeric