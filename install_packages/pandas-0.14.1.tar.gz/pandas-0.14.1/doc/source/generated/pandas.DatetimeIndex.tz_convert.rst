pandas.DatetimeIndex.tz_convert
===============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.tz_convert