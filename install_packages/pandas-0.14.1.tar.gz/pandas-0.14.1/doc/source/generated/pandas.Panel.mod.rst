pandas.Panel.mod
================

.. currentmodule:: pandas

.. automethod:: Panel.mod