pandas.Panel4D.groupby
======================

.. currentmodule:: pandas

.. automethod:: Panel4D.groupby