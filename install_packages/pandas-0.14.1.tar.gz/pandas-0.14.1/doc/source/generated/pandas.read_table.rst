pandas.read_table
=================

.. currentmodule:: pandas

.. autofunction:: read_table