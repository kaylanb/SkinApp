pandas.Index.is_monotonic
=========================

.. currentmodule:: pandas

.. autoattribute:: Index.is_monotonic