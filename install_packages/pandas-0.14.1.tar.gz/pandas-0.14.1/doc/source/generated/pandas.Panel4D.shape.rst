pandas.Panel4D.shape
====================

.. currentmodule:: pandas

.. autoattribute:: Panel4D.shape