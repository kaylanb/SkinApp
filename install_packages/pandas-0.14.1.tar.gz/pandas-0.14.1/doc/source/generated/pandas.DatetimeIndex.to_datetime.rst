pandas.DatetimeIndex.to_datetime
================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.to_datetime