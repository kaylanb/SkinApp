pandas.DatetimeIndex.second
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.second