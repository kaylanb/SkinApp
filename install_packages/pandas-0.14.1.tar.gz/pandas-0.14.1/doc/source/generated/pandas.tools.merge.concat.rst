pandas.tools.merge.concat
=========================

.. currentmodule:: pandas.tools.merge

.. autofunction:: concat