pandas.DatetimeIndex.groupby
============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.groupby