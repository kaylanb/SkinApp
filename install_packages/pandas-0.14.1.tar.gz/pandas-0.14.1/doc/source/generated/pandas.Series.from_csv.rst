pandas.Series.from_csv
======================

.. currentmodule:: pandas

.. automethod:: Series.from_csv