pandas.Index.summary
====================

.. currentmodule:: pandas

.. automethod:: Index.summary