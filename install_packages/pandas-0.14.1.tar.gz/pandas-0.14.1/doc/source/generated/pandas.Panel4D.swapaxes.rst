pandas.Panel4D.swapaxes
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.swapaxes