pandas.Series.consolidate
=========================

.. currentmodule:: pandas

.. automethod:: Series.consolidate