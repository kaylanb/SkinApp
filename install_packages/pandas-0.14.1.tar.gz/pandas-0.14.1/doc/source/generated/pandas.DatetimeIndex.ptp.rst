pandas.DatetimeIndex.ptp
========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.ptp