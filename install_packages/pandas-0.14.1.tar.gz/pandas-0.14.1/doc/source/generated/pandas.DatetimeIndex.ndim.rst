pandas.DatetimeIndex.ndim
=========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.ndim