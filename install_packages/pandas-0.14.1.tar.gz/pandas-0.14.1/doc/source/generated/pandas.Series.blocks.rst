pandas.Series.blocks
====================

.. currentmodule:: pandas

.. autoattribute:: Series.blocks