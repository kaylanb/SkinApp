pandas.Panel4D.resample
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.resample