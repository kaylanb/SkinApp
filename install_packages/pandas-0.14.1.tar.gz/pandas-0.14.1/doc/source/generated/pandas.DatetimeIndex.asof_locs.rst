pandas.DatetimeIndex.asof_locs
==============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.asof_locs