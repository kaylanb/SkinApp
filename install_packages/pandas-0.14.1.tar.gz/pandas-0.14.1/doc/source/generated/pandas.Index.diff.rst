pandas.Index.diff
=================

.. currentmodule:: pandas

.. automethod:: Index.diff