pandas.Panel.to_pickle
======================

.. currentmodule:: pandas

.. automethod:: Panel.to_pickle