pandas.Index.is_
================

.. currentmodule:: pandas

.. automethod:: Index.is_