pandas.Index.nonzero
====================

.. currentmodule:: pandas

.. automethod:: Index.nonzero