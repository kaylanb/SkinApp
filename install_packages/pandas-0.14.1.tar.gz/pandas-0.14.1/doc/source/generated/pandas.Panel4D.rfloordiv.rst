pandas.Panel4D.rfloordiv
========================

.. currentmodule:: pandas

.. automethod:: Panel4D.rfloordiv