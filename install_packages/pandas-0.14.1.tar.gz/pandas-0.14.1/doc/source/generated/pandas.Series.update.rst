pandas.Series.update
====================

.. currentmodule:: pandas

.. automethod:: Series.update