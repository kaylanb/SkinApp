pandas.DatetimeIndex.to_pydatetime
==================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.to_pydatetime