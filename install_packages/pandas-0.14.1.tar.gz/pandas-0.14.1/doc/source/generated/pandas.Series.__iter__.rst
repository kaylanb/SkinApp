pandas.Series.__iter__
======================

.. currentmodule:: pandas

.. automethod:: Series.__iter__