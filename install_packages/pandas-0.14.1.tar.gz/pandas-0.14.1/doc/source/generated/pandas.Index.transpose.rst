pandas.Index.transpose
======================

.. currentmodule:: pandas

.. automethod:: Index.transpose