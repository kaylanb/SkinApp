pandas.Index.flatten
====================

.. currentmodule:: pandas

.. automethod:: Index.flatten