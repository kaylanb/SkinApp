pandas.Series.swaplevel
=======================

.. currentmodule:: pandas

.. automethod:: Series.swaplevel