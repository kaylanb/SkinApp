pandas.Index.is_type_compatible
===============================

.. currentmodule:: pandas

.. automethod:: Index.is_type_compatible