pandas.Series.data
==================

.. currentmodule:: pandas

.. autoattribute:: Series.data