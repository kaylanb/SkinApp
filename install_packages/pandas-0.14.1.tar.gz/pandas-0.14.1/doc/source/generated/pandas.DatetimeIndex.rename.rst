pandas.DatetimeIndex.rename
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.rename