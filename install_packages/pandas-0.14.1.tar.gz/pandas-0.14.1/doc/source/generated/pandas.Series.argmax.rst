pandas.Series.argmax
====================

.. currentmodule:: pandas

.. automethod:: Series.argmax