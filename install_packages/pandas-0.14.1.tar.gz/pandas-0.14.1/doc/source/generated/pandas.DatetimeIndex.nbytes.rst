pandas.DatetimeIndex.nbytes
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.nbytes