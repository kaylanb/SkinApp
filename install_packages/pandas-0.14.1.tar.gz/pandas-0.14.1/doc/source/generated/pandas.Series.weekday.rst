pandas.Series.weekday
=====================

.. currentmodule:: pandas

.. autoattribute:: Series.weekday