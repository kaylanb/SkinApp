pandas.Index.newbyteorder
=========================

.. currentmodule:: pandas

.. automethod:: Index.newbyteorder