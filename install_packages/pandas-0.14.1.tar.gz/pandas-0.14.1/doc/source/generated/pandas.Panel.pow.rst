pandas.Panel.pow
================

.. currentmodule:: pandas

.. automethod:: Panel.pow