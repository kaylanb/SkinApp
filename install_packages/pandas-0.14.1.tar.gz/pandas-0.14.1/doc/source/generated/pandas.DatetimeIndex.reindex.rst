pandas.DatetimeIndex.reindex
============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.reindex