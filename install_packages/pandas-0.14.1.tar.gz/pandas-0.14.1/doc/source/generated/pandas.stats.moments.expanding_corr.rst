pandas.stats.moments.expanding_corr
===================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: expanding_corr