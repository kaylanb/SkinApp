pandas.Index.resize
===================

.. currentmodule:: pandas

.. automethod:: Index.resize