pandas.stats.moments.expanding_apply
====================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: expanding_apply