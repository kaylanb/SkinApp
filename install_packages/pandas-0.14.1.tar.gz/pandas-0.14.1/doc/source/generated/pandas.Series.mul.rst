pandas.Series.mul
=================

.. currentmodule:: pandas

.. automethod:: Series.mul