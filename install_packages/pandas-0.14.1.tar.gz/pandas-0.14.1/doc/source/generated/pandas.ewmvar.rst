pandas.ewmvar
=============

.. currentmodule:: pandas

.. autofunction:: ewmvar