pandas.DatetimeIndex.diff
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.diff