pandas.Series.resample
======================

.. currentmodule:: pandas

.. automethod:: Series.resample