pandas.stats.moments.expanding_std
==================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: expanding_std