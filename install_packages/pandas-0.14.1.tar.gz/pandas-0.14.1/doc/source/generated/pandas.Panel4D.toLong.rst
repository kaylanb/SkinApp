pandas.Panel4D.toLong
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.toLong