pandas.Index.holds_integer
==========================

.. currentmodule:: pandas

.. automethod:: Index.holds_integer