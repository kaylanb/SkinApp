pandas.Series.std
=================

.. currentmodule:: pandas

.. automethod:: Series.std