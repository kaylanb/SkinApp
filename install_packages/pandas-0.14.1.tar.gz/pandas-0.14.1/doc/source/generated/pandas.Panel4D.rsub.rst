pandas.Panel4D.rsub
===================

.. currentmodule:: pandas

.. automethod:: Panel4D.rsub