pandas.Panel.ndim
=================

.. currentmodule:: pandas

.. autoattribute:: Panel.ndim