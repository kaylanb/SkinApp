pandas.DataFrame.ndim
=====================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.ndim