pandas.Panel.add_prefix
=======================

.. currentmodule:: pandas

.. automethod:: Panel.add_prefix