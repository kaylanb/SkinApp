pandas.Series.head
==================

.. currentmodule:: pandas

.. automethod:: Series.head