pandas.Series.valid
===================

.. currentmodule:: pandas

.. automethod:: Series.valid