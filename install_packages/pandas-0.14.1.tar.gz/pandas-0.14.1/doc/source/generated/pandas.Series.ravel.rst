pandas.Series.ravel
===================

.. currentmodule:: pandas

.. automethod:: Series.ravel