pandas.Panel4D.where
====================

.. currentmodule:: pandas

.. automethod:: Panel4D.where