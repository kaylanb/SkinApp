pandas.io.excel.read_excel
==========================

.. currentmodule:: pandas.io.excel

.. autofunction:: read_excel