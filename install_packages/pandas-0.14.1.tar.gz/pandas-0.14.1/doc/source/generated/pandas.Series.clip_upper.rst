pandas.Series.clip_upper
========================

.. currentmodule:: pandas

.. automethod:: Series.clip_upper