pandas.Index.dump
=================

.. currentmodule:: pandas

.. automethod:: Index.dump