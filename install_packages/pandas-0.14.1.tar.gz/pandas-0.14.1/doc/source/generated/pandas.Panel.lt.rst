pandas.Panel.lt
===============

.. currentmodule:: pandas

.. automethod:: Panel.lt