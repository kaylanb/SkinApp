pandas.Series.is_time_series
============================

.. currentmodule:: pandas

.. autoattribute:: Series.is_time_series