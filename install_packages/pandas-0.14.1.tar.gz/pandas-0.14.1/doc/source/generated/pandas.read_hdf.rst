pandas.read_hdf
===============

.. currentmodule:: pandas

.. autofunction:: read_hdf