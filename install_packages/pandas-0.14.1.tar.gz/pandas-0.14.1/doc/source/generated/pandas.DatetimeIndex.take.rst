pandas.DatetimeIndex.take
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.take