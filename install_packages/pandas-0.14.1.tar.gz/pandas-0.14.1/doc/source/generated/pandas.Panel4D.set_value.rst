pandas.Panel4D.set_value
========================

.. currentmodule:: pandas

.. automethod:: Panel4D.set_value