pandas.DatetimeIndex.size
=========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.size