pandas.DatetimeIndex.format
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.format