pandas.Series.median
====================

.. currentmodule:: pandas

.. automethod:: Series.median