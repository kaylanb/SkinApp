pandas.core.strings.StringMethods.startswith
============================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.startswith