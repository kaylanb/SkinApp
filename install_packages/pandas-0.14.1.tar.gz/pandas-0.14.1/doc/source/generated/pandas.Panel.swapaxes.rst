pandas.Panel.swapaxes
=====================

.. currentmodule:: pandas

.. automethod:: Panel.swapaxes