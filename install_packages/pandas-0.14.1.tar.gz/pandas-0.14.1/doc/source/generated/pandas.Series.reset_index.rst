pandas.Series.reset_index
=========================

.. currentmodule:: pandas

.. automethod:: Series.reset_index