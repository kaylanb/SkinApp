pandas.rolling_max
==================

.. currentmodule:: pandas

.. autofunction:: rolling_max