pandas.expanding_corr
=====================

.. currentmodule:: pandas

.. autofunction:: expanding_corr