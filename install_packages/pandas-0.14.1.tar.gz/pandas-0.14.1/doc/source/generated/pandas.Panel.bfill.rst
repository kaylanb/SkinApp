pandas.Panel.bfill
==================

.. currentmodule:: pandas

.. automethod:: Panel.bfill