pandas.core.strings.StringMethods.replace
=========================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.replace