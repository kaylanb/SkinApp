pandas.stats.moments.ewmvar
===========================

.. currentmodule:: pandas.stats.moments

.. autofunction:: ewmvar