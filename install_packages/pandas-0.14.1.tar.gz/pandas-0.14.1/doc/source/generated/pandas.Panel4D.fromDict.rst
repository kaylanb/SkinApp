pandas.Panel4D.fromDict
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.fromDict