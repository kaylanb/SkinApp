pandas.DataFrame.ne
===================

.. currentmodule:: pandas

.. automethod:: DataFrame.ne