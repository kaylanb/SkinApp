pandas.Panel4D.update
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.update