pandas.Series.get
=================

.. currentmodule:: pandas

.. automethod:: Series.get