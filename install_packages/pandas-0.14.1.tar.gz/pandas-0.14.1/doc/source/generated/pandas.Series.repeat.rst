pandas.Series.repeat
====================

.. currentmodule:: pandas

.. automethod:: Series.repeat