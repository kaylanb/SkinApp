pandas.rolling_window
=====================

.. currentmodule:: pandas

.. autofunction:: rolling_window