pandas.Panel4D.filter
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.filter