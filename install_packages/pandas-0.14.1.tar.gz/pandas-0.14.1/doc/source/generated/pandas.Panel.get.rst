pandas.Panel.get
================

.. currentmodule:: pandas

.. automethod:: Panel.get