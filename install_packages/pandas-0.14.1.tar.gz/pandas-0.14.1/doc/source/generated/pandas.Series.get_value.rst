pandas.Series.get_value
=======================

.. currentmodule:: pandas

.. automethod:: Series.get_value