pandas.Panel.update
===================

.. currentmodule:: pandas

.. automethod:: Panel.update