pandas.io.gbq.to_gbq
====================

.. currentmodule:: pandas.io.gbq

.. autofunction:: to_gbq