pandas.DatetimeIndex.real
=========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.real