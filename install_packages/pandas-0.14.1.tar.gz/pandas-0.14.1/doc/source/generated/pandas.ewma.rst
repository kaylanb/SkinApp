pandas.ewma
===========

.. currentmodule:: pandas

.. autofunction:: ewma