pandas.DatetimeIndex.is_lexsorted_for_tuple
===========================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.is_lexsorted_for_tuple