pandas.stats.moments.rolling_apply
==================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: rolling_apply