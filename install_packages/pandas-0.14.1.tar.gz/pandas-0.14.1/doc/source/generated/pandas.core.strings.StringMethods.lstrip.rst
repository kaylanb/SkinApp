pandas.core.strings.StringMethods.lstrip
========================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.lstrip