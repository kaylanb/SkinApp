pandas.Series.multiply
======================

.. currentmodule:: pandas

.. automethod:: Series.multiply