pandas.Index.is_lexsorted_for_tuple
===================================

.. currentmodule:: pandas

.. automethod:: Index.is_lexsorted_for_tuple