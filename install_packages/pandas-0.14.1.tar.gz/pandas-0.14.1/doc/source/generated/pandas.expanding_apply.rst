pandas.expanding_apply
======================

.. currentmodule:: pandas

.. autofunction:: expanding_apply