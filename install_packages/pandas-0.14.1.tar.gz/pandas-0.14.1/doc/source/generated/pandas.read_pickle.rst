pandas.read_pickle
==================

.. currentmodule:: pandas

.. autofunction:: read_pickle