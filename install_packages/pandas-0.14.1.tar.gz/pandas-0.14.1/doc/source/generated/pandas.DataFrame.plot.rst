pandas.DataFrame.plot
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.plot