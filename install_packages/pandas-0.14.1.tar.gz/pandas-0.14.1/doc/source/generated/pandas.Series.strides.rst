pandas.Series.strides
=====================

.. currentmodule:: pandas

.. autoattribute:: Series.strides