pandas.expanding_count
======================

.. currentmodule:: pandas

.. autofunction:: expanding_count