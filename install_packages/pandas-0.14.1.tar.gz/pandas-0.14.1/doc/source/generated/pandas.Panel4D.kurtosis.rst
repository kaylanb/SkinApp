pandas.Panel4D.kurtosis
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.kurtosis