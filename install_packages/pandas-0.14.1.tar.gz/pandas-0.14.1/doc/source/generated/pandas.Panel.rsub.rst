pandas.Panel.rsub
=================

.. currentmodule:: pandas

.. automethod:: Panel.rsub