pandas.stats.moments.expanding_median
=====================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: expanding_median