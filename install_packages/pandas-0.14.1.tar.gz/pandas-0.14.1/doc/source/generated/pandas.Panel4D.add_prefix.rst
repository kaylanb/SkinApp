pandas.Panel4D.add_prefix
=========================

.. currentmodule:: pandas

.. automethod:: Panel4D.add_prefix