pandas.Panel.reindex_like
=========================

.. currentmodule:: pandas

.. automethod:: Panel.reindex_like