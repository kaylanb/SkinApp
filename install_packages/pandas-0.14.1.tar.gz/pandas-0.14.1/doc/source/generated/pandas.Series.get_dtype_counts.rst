pandas.Series.get_dtype_counts
==============================

.. currentmodule:: pandas

.. automethod:: Series.get_dtype_counts