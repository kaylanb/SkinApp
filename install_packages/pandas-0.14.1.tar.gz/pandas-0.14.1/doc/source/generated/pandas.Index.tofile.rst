pandas.Index.tofile
===================

.. currentmodule:: pandas

.. automethod:: Index.tofile