pandas.DatetimeIndex.tostring
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.tostring