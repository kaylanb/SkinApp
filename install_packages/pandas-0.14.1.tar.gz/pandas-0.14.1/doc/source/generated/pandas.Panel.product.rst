pandas.Panel.product
====================

.. currentmodule:: pandas

.. automethod:: Panel.product