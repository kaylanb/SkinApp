pandas.Series.reindex_axis
==========================

.. currentmodule:: pandas

.. automethod:: Series.reindex_axis