pandas.Panel4D.dropna
=====================

.. currentmodule:: pandas

.. automethod:: Panel4D.dropna