pandas.DataFrame.to_sparse
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_sparse