pandas.HDFStore.append
======================

.. currentmodule:: pandas

.. automethod:: HDFStore.append