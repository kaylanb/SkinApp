pandas.Series.clip
==================

.. currentmodule:: pandas

.. automethod:: Series.clip