pandas.Index.sort
=================

.. currentmodule:: pandas

.. automethod:: Index.sort