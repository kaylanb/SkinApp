pandas.stats.moments.ewmstd
===========================

.. currentmodule:: pandas.stats.moments

.. autofunction:: ewmstd