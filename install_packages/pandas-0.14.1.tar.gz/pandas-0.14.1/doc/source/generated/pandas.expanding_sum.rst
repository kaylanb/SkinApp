pandas.expanding_sum
====================

.. currentmodule:: pandas

.. autofunction:: expanding_sum