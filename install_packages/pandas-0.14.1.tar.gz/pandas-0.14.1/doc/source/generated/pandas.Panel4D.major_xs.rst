pandas.Panel4D.major_xs
=======================

.. currentmodule:: pandas

.. automethod:: Panel4D.major_xs