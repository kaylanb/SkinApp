pandas.Index.drop
=================

.. currentmodule:: pandas

.. automethod:: Index.drop