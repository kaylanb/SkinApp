pandas.Series.rank
==================

.. currentmodule:: pandas

.. automethod:: Series.rank