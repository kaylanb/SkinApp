pandas.Index.sum
================

.. currentmodule:: pandas

.. automethod:: Index.sum