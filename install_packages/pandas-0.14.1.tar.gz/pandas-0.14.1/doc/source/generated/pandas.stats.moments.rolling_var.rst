pandas.stats.moments.rolling_var
================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: rolling_var