pandas.Series.eq
================

.. currentmodule:: pandas

.. automethod:: Series.eq