pandas.DataFrame.to_sql
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_sql