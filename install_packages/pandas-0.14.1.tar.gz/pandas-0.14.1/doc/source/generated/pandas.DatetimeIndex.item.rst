pandas.DatetimeIndex.item
=========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.item