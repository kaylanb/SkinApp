pandas.DatetimeIndex.sum
========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.sum