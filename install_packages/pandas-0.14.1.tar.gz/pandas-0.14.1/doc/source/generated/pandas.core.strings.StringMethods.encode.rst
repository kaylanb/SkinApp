pandas.core.strings.StringMethods.encode
========================================

.. currentmodule:: pandas.core.strings

.. automethod:: StringMethods.encode