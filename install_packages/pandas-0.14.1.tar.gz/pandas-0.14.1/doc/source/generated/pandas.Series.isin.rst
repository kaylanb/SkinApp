pandas.Series.isin
==================

.. currentmodule:: pandas

.. automethod:: Series.isin