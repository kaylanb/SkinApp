pandas.Panel.iteritems
======================

.. currentmodule:: pandas

.. automethod:: Panel.iteritems