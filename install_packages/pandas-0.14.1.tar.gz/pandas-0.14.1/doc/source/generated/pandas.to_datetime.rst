pandas.to_datetime
==================

.. currentmodule:: pandas

.. autofunction:: to_datetime