pandas.Panel.add
================

.. currentmodule:: pandas

.. automethod:: Panel.add