pandas.Series.skew
==================

.. currentmodule:: pandas

.. automethod:: Series.skew