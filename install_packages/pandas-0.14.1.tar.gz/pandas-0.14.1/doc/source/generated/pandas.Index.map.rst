pandas.Index.map
================

.. currentmodule:: pandas

.. automethod:: Index.map