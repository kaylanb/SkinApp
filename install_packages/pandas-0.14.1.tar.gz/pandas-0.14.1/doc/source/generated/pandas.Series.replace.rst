pandas.Series.replace
=====================

.. currentmodule:: pandas

.. automethod:: Series.replace