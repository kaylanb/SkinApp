pandas.DataFrame.get_ftype_counts
=================================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_ftype_counts