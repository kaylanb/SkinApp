pandas.Series.to_json
=====================

.. currentmodule:: pandas

.. automethod:: Series.to_json