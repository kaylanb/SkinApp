pandas.Series.axes
==================

.. currentmodule:: pandas

.. autoattribute:: Series.axes