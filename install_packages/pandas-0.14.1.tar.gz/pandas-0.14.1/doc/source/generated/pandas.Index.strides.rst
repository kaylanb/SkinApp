pandas.Index.strides
====================

.. currentmodule:: pandas

.. autoattribute:: Index.strides