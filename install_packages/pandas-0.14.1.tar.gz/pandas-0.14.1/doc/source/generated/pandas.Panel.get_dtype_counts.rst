pandas.Panel.get_dtype_counts
=============================

.. currentmodule:: pandas

.. automethod:: Panel.get_dtype_counts