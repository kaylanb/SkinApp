pandas.Series.base
==================

.. currentmodule:: pandas

.. autoattribute:: Series.base