pandas.Series.corr
==================

.. currentmodule:: pandas

.. automethod:: Series.corr