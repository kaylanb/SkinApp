pandas.Index.cumprod
====================

.. currentmodule:: pandas

.. automethod:: Index.cumprod