pandas.Panel4D.prod
===================

.. currentmodule:: pandas

.. automethod:: Panel4D.prod