pandas.stats.moments.rolling_sum
================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: rolling_sum