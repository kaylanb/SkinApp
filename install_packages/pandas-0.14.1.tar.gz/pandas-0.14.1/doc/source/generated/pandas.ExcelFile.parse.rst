pandas.ExcelFile.parse
======================

.. currentmodule:: pandas

.. automethod:: ExcelFile.parse