pandas.Index.byteswap
=====================

.. currentmodule:: pandas

.. automethod:: Index.byteswap