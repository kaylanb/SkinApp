pandas.DataFrame.dot
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.dot