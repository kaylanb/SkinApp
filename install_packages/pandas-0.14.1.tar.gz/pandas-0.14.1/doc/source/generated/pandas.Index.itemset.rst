pandas.Index.itemset
====================

.. currentmodule:: pandas

.. automethod:: Index.itemset