pandas.Panel.kurtosis
=====================

.. currentmodule:: pandas

.. automethod:: Panel.kurtosis