pandas.DatetimeIndex.delete
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.delete