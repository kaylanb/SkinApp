pandas.Panel4D.as_matrix
========================

.. currentmodule:: pandas

.. automethod:: Panel4D.as_matrix