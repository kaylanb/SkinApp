pandas.DataFrame.query
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.query