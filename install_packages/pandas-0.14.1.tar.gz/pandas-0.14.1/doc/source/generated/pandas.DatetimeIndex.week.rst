pandas.DatetimeIndex.week
=========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.week