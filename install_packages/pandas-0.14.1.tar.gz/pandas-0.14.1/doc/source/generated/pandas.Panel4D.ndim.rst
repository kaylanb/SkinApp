pandas.Panel4D.ndim
===================

.. currentmodule:: pandas

.. autoattribute:: Panel4D.ndim