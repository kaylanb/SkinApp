pandas.ewmcorr
==============

.. currentmodule:: pandas

.. autofunction:: ewmcorr