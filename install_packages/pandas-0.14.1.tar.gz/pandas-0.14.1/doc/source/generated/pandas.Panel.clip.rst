pandas.Panel.clip
=================

.. currentmodule:: pandas

.. automethod:: Panel.clip