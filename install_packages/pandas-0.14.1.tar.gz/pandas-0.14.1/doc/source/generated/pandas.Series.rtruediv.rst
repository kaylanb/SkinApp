pandas.Series.rtruediv
======================

.. currentmodule:: pandas

.. automethod:: Series.rtruediv