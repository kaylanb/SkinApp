pandas.Series.between
=====================

.. currentmodule:: pandas

.. automethod:: Series.between