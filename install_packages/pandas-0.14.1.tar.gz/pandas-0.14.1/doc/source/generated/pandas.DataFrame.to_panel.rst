pandas.DataFrame.to_panel
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_panel