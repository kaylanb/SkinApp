pandas.io.sql.read_sql
======================

.. currentmodule:: pandas.io.sql

.. autofunction:: read_sql