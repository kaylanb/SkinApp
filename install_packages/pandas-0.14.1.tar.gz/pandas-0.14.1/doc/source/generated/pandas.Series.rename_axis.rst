pandas.Series.rename_axis
=========================

.. currentmodule:: pandas

.. automethod:: Series.rename_axis