pandas.Panel.prod
=================

.. currentmodule:: pandas

.. automethod:: Panel.prod