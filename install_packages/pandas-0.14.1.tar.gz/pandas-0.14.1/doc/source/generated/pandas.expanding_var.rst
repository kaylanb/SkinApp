pandas.expanding_var
====================

.. currentmodule:: pandas

.. autofunction:: expanding_var