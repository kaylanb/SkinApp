pandas.Panel4D.tz_localize
==========================

.. currentmodule:: pandas

.. automethod:: Panel4D.tz_localize