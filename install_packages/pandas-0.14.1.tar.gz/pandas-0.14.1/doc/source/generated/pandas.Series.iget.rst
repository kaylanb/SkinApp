pandas.Series.iget
==================

.. currentmodule:: pandas

.. automethod:: Series.iget