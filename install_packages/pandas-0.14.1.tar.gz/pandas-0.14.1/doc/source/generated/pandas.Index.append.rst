pandas.Index.append
===================

.. currentmodule:: pandas

.. automethod:: Index.append