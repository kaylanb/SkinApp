pandas.Series.date
==================

.. currentmodule:: pandas

.. autoattribute:: Series.date