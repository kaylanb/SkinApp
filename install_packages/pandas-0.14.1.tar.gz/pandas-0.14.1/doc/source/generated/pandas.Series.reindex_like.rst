pandas.Series.reindex_like
==========================

.. currentmodule:: pandas

.. automethod:: Series.reindex_like