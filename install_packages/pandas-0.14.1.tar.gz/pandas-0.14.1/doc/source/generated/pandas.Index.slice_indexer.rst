pandas.Index.slice_indexer
==========================

.. currentmodule:: pandas

.. automethod:: Index.slice_indexer