pandas.Index.squeeze
====================

.. currentmodule:: pandas

.. automethod:: Index.squeeze