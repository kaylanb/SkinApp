pandas.Series.save
==================

.. currentmodule:: pandas

.. automethod:: Series.save