pandas.Panel.to_long
====================

.. currentmodule:: pandas

.. automethod:: Panel.to_long