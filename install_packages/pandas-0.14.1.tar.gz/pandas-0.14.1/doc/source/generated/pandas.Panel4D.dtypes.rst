pandas.Panel4D.dtypes
=====================

.. currentmodule:: pandas

.. autoattribute:: Panel4D.dtypes