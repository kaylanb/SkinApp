pandas.Series.mad
=================

.. currentmodule:: pandas

.. automethod:: Series.mad