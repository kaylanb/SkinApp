pandas.DatetimeIndex.flags
==========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.flags