pandas.stats.moments.expanding_skew
===================================

.. currentmodule:: pandas.stats.moments

.. autofunction:: expanding_skew