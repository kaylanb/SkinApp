pandas.Panel.truncate
=====================

.. currentmodule:: pandas

.. automethod:: Panel.truncate