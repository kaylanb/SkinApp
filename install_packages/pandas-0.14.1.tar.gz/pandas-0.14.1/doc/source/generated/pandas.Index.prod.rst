pandas.Index.prod
=================

.. currentmodule:: pandas

.. automethod:: Index.prod